class AttributeSetter:
    def __init__(self, name, value):
        setattr(self, name, value)
