# coding: pyxl
from pyxl import html
def test():
    assert str(<div style="background-color: #1f75cc;"></div>) == """<div style="background-color: #1f75cc;"></div>"""
