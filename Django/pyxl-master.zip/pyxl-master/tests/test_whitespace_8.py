# coding: pyxl
from pyxl import html
def test():
    assert str(<frag>{ 'foo' }{ 'foo' }</frag>) == "foofoo"
