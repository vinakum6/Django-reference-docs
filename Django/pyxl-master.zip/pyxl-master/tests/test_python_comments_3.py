# coding: pyxl
from pyxl import html
def test():
    assert str(<div #style="display: none;"
               ></div>) == "<div></div>"
