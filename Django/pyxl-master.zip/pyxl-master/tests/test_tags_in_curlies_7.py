# coding: pyxl
from pyxl import html
def test():
    assert str(<frag> {' "<br />" '} </frag>) == '''  &quot;&lt;br /&gt;&quot;  '''
