import pyxl.codec.register
