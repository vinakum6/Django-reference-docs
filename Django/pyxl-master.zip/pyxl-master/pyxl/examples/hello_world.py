# coding: pyxl

from pyxl import html

print <html><body>Hello World!</body></html>
